
from django.contrib import admin
from django.urls import path, include
from home import views

urlpatterns = [
    path('',views.index, name='index'),
    path('home/',views.home, name='home'),
    path('ourproduct/', views.ourproduct, name='ourproduct'),
    path('contact/', views.contact, name='contact'),
    path('aboutus/', views.aboutus, name='aboutus'),
]
